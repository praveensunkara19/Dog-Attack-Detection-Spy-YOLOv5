# dog detection > 2023-07-20 10:12pm
https://universe.roboflow.com/dog-bite-detection/dog-detection-is87r

Provided by a Roboflow user
License: CC BY 4.0

